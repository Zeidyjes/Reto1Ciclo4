package com.catalogo.colonias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ColoniasApplicationTests {

	@Test
	void contextLoads() {
	}

}
